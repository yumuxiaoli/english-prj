package com.enstudy.demo.controller.form;

import lombok.Data;

/**
 * 七牛云前端上传文件获取token的form
 */
@Data
public class TokenForm {
    private String fileName;
}