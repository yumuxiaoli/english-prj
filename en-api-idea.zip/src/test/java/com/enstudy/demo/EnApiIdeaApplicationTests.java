//package com.enstudy.demo;
//
//import org.junit.jupiter.api.SqlTableCreateUtil;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class EnApiIdeaApplicationTests {
//
//    @SqlTableCreateUtil
//    void contextLoads() {
//
//    }
//
//}
